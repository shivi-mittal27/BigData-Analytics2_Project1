
import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams["figure.figsize"] = [10, 6]
plt.xlabel("Date")
plt.ylabel("Sales")


data = pd.read_csv("E:/SD\Sem-7/Big Data & Data Analytics - 2/Week10/Project/BreadBasket_DMS.csv")

data['Date'] = pd.to_datetime(data['Date'],format='%d-%m-%Y', errors='coerce')
data['year'] = data['Date'].dt.year

lol= data.loc[data['year'] == 2017]



coffee= lol.set_index(['Item'])
onlycoffee= coffee.loc['Coffee']
onlycoffee.reset_index(inplace = True)

popular=onlycoffee['Date'].value_counts()

print("Question 9")

print("\nTop 5 dates on which sales of coffee was highest: \n")
print("Date          Total")
print(popular.head())

popular.head().plot(kind='line', color='blue', marker='o')
plt.title("Top 5 sales day for coffee")
plt.show()


